#!/bin/sh

python3 unit_tests.py ${@}